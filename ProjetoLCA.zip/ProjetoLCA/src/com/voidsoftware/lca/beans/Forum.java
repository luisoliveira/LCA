package com.voidsoftware.lca.beans;

public class Forum extends Pessoa {
	
	public Forum(){
		
	}
	
	private String descricao;

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
