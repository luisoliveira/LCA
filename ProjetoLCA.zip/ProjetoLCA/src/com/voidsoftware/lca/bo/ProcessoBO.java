package com.voidsoftware.lca.bo;

public class ProcessoBO {

}
