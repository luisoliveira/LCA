package com.voidsoftware.lca.testes;

import com.voidsoftware.lca.beans.Cliente;

public class TesteHeranca {
	
	public static void main(String [] args){
		
		Cliente cl = new Cliente();
		
		cl.setCodigo(1);
		
		
		
	}
	
}
